r"""
Integration models
"""

import os

from .base import Model
from .scglue import AUTO, PairedSCGLUEModel, SCGLUEModel, configure_dataset
from .scclue import SCCLUEModel


def load_model(fname: os.PathLike) -> Model:
    r"""
    Load model from file

    Parameters
    ----------
    fname
        Specifies path to the file
    """
    return Model.load(fname)
